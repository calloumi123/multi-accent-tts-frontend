"""Command-line interface for the multi-accent frontend.

Examples:
    # transcribe one sentence to stdout
    multi-accent-frontend transcribe -m ./bundle -a gam "hello world"

    # transcribe a file (one sentence per line) into an output file
    multi-accent-frontend transcribe -m org/repo -a rpx -i in.txt -o out.txt

    # list the accents a bundle supports
    multi-accent-frontend accents -m ./bundle
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path

from . import __version__
from .frontend import Frontend


def _read_lines(input_path: str | None, inline: Sequence[str]) -> list[str]:
    if input_path is not None:
        text = Path(input_path).read_text(encoding="utf-8")
        return [line.strip() for line in text.splitlines() if line.strip()]
    if inline:
        return [" ".join(inline)]
    return [line.strip() for line in sys.stdin if line.strip()]


def _cmd_transcribe(args: argparse.Namespace) -> int:
    frontend = Frontend.from_pretrained(args.model, device=args.device)
    lines = _read_lines(args.input, args.text)
    outputs = frontend.transcribe(
        lines,
        accent=args.accent,
        decoding=args.decoding,
        beam_size=args.beam_size,
        max_decoder_steps=args.max_decoder_steps,
        batch_size=args.batch_size,
        uppercase=not args.no_uppercase,
    )
    rendered = "\n".join(outputs) + "\n"
    if args.output is not None:
        Path(args.output).write_text(rendered, encoding="utf-8")
        print(f"wrote {len(outputs)} line(s) to {args.output}", file=sys.stderr)
    else:
        sys.stdout.write(rendered)
    return 0


def _cmd_accents(args: argparse.Namespace) -> int:
    frontend = Frontend.from_pretrained(args.model, device=args.device)
    for idx, name in enumerate(frontend.accents):
        print(f"{idx}\t{name}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="multi-accent-frontend",
        description="Multi-accent seq2seq linguistic frontend for TTS.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "-m", "--model", required=True,
        help="Local bundle directory or Hugging Face Hub repo id.",
    )
    common.add_argument(
        "--device", default=None,
        help="Torch device (e.g. cpu, cuda). Defaults to CUDA if available.",
    )

    p_tr = subparsers.add_parser(
        "transcribe", parents=[common], help="Transcribe text to phones."
    )
    p_tr.add_argument("text", nargs="*", help="Inline text to transcribe.")
    p_tr.add_argument("-a", "--accent", required=True, help="Accent name or index.")
    p_tr.add_argument("-i", "--input", default=None, help="Input file, one sentence per line.")
    p_tr.add_argument("-o", "--output", default=None, help="Output file (default: stdout).")
    p_tr.add_argument(
        "--decoding", choices=["greedy", "beam_search"], default="greedy",
        help="Decoding method (default: greedy).",
    )
    p_tr.add_argument("--beam-size", type=int, default=5, help="Beam width for beam search.")
    p_tr.add_argument("--batch-size", type=int, default=8, help="Batch size for greedy decoding.")
    p_tr.add_argument("--max-decoder-steps", type=int, default=500, help="Output length cap.")
    p_tr.add_argument(
        "--no-uppercase", action="store_true",
        help="Do not upper-case the input before inference.",
    )
    p_tr.set_defaults(func=_cmd_transcribe)

    p_ac = subparsers.add_parser(
        "accents", parents=[common], help="List supported accents."
    )
    p_ac.set_defaults(func=_cmd_accents)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
