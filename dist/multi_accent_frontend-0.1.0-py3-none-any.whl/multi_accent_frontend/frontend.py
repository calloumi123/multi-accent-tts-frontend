"""High-level, in-memory API for the multi-accent seq2seq frontend.

The research code exposes inference only as a command-line script that reads a
text file and writes phone/alignment files to disk. This module wraps the same
model in a small, typed class so that library users can do:

    >>> from multi_accent_frontend import Frontend
    >>> fe = Frontend.from_pretrained("some-org/multi-accent-frontend")
    >>> fe.transcribe("HELLO WORLD", accent="gam")
    'h @ l ou + w @@r l d'

No files are written and no notebook/IPython dependency is required.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import overload

import numpy as np
import torch

from ._research.model import setup_model
from ._research.padding import prepare_char
from .config import EOS_TOKEN, WORD_DELIMITER, FrontendConfig, Vocab
from .hub import resolve_bundle

DecodingMethod = str  # "greedy" or "beam_search"


class Frontend:
    """A loaded multi-accent linguistic frontend ready for inference.

    Prefer constructing this with :meth:`from_pretrained`. The plain
    constructor is available for advanced use when the pieces are already in
    memory.
    """

    def __init__(
        self,
        model: torch.nn.Module,
        config: FrontendConfig,
        src_vocab: Vocab,
        tgt_vocab: Vocab,
        device: torch.device,
    ) -> None:
        self._model = model
        self._config = config
        self._src_vocab = src_vocab
        self._tgt_vocab = tgt_vocab
        self._device = device
        self._model.eval()

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    @classmethod
    def from_pretrained(
        cls,
        model: str | Path,
        *,
        device: str | torch.device | None = None,
        weights_filename: str | None = None,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        token: str | None = None,
    ) -> Frontend:
        """Load a frontend from a local directory or a Hugging Face Hub repo.

        Args:
            model: A local bundle directory, or a Hub repo id. See
                :func:`multi_accent_frontend.hub.resolve_bundle` for the files
                a bundle must contain.
            device: Torch device to place the model on. Defaults to CUDA when
                available, otherwise CPU.
            weights_filename: Explicit checkpoint filename inside the bundle.
            revision: Optional Hub revision to download.
            cache_dir: Optional Hub download cache directory.
            token: Optional Hugging Face token for private repos.

        Returns:
            A ready-to-use :class:`Frontend`.
        """
        bundle = resolve_bundle(
            model,
            weights_filename=weights_filename,
            revision=revision,
            cache_dir=cache_dir,
            token=token,
        )
        resolved_device = _resolve_device(device)

        config = FrontendConfig.from_file(bundle.config)
        src_vocab = Vocab.from_file(bundle.src_vocab)
        tgt_vocab = Vocab.from_file(bundle.tgt_vocab)

        net = setup_model(
            c=config.raw,
            num_chars=src_vocab.num_tokens,
            num_phones=tgt_vocab.num_tokens,
        )
        state_dict = _load_state_dict(bundle.weights, resolved_device)
        net.load_state_dict(state_dict)
        net.to(resolved_device)

        return cls(
            model=net,
            config=config,
            src_vocab=src_vocab,
            tgt_vocab=tgt_vocab,
            device=resolved_device,
        )

    # ------------------------------------------------------------------ #
    # Introspection
    # ------------------------------------------------------------------ #
    @property
    def accents(self) -> list[str]:
        """Accent names this model supports, in index order."""
        return self._config.accents

    @property
    def device(self) -> torch.device:
        return self._device

    # ------------------------------------------------------------------ #
    # Inference
    # ------------------------------------------------------------------ #
    @overload
    def transcribe(
        self, text: str, accent: str | int, *,
        decoding: DecodingMethod = ..., beam_size: int = ..., max_decoder_steps: int = ...,
        batch_size: int = ..., uppercase: bool = ...,
    ) -> str: ...
    @overload
    def transcribe(
        self, text: list[str], accent: str | int, *,
        decoding: DecodingMethod = ..., beam_size: int = ..., max_decoder_steps: int = ...,
        batch_size: int = ..., uppercase: bool = ...,
    ) -> list[str]: ...

    def transcribe(
        self,
        text: str | list[str],
        accent: str | int,
        *,
        decoding: DecodingMethod = "greedy",
        beam_size: int = 5,
        max_decoder_steps: int = 500,
        batch_size: int = 8,
        uppercase: bool = True,
    ) -> str | list[str]:
        """Transcribe normalised text into a phone/linguistic string.

        Args:
            text: A single normalised sentence, or a list of them. Input should
                already be text-normalised (numbers/punctuation expanded); this
                model maps orthography to pronunciation.
            accent: Accent name (e.g. ``"gam"``) or integer index.
            decoding: ``"greedy"`` (batched, fast) or ``"beam_search"``
                (one sentence at a time, usually a little more accurate).
            beam_size: Beam width when ``decoding="beam_search"``.
            max_decoder_steps: Safety cap on output length.
            batch_size: Batch size for greedy decoding. Ignored for beam search,
                which the underlying model runs one sentence at a time.
            uppercase: Upper-case the input to match the training distribution.

        Returns:
            A phone string when ``text`` is a ``str``; a list of phone strings
            (aligned to the input order) when ``text`` is a list.
        """
        if isinstance(text, str):
            lines: list[str] = [text]
            single_input = True
        else:
            lines = list(text)
            single_input = False
        lang_idx = self._config.resolve_accent(accent)

        results: list[str] = []
        if decoding == "beam_search":
            for line in lines:
                candidates = self._infer_batch(
                    [line], lang_idx, "beam_search", beam_size, max_decoder_steps, uppercase
                )
                results.append(candidates[0])
        else:
            for start in range(0, len(lines), batch_size):
                batch = lines[start : start + batch_size]
                results.extend(
                    self._infer_batch(
                        batch, lang_idx, "greedy", beam_size, max_decoder_steps, uppercase
                    )
                )

        return results[0] if single_input else results

    def transcribe_nbest(
        self,
        text: str,
        accent: str | int,
        *,
        beam_size: int = 5,
        n_best: int = 5,
        max_decoder_steps: int = 500,
        uppercase: bool = True,
    ) -> list[str]:
        """Return the top ``n_best`` beam-search candidates for one sentence.

        Args:
            text: A single normalised sentence.
            accent: Accent name or integer index.
            beam_size: Beam width; must be >= ``n_best``.
            n_best: Number of candidate transcriptions to return.
            max_decoder_steps: Safety cap on output length.
            uppercase: Upper-case the input to match the training distribution.

        Returns:
            Up to ``n_best`` phone strings, best first.
        """
        if not isinstance(text, str):
            raise TypeError("transcribe_nbest expects a single string")
        lang_idx = self._config.resolve_accent(accent)
        candidates = self._infer_batch(
            [text], lang_idx, "beam_search", beam_size, max_decoder_steps, uppercase
        )
        return candidates[:n_best]

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _encode_line(self, line: str, uppercase: bool) -> np.ndarray:
        """Turn one text line into an array of source character indices."""
        if uppercase:
            line = line.upper()
        char_list = list(line.replace(" ", WORD_DELIMITER)) + [EOS_TOKEN]
        try:
            return np.array([self._src_vocab.token2idx[ch] for ch in char_list])
        except KeyError as exc:
            bad = exc.args[0]
            raise ValueError(
                f"input character {bad!r} is not in the source vocabulary. "
                "Make sure the text is normalised (letters and apostrophes only)."
            ) from exc

    @torch.no_grad()
    def _infer_batch(
        self,
        lines: list[str],
        lang_idx: int,
        decoding: DecodingMethod,
        beam_size: int,
        max_decoder_steps: int,
        uppercase: bool,
    ) -> list[str]:
        """Run the model over a batch and return decoded phone strings.

        For greedy decoding this yields one string per input line. For beam
        search (``len(lines) == 1``) it yields the beam candidates, best first.
        """
        char_arrays = [self._encode_line(line, uppercase) for line in lines]
        padded = prepare_char(char_arrays, pad_value=self._src_vocab.pad_idx)
        chars = torch.as_tensor(padded, dtype=torch.long, device=self._device)
        langs = torch.full(
            (len(lines),), lang_idx, dtype=torch.long, device=self._device
        )

        _, post_outputs, _, _, hypothesis, _ = self._model.inference(
            chars,
            langs,
            max_decoder_steps=max_decoder_steps,
            decoding_method=decoding,
            beam_size=beam_size,
        )

        has_postnet = bool(self._config.raw.get("has_postnet", False))
        if has_postnet and post_outputs is not None:
            index_rows = np.argmax(post_outputs.cpu().numpy(), axis=-1)
        else:
            index_rows = hypothesis.cpu().numpy()

        return [self._decode_phones(row) for row in index_rows]

    def _decode_phones(self, indices: Sequence[int]) -> str:
        """Map phone indices to a space-joined string, trimmed at EOS."""
        idx2phone = self._tgt_vocab.idx2token
        phones = " ".join(idx2phone[int(idx)] for idx in indices)
        return phones.split(EOS_TOKEN)[0].rstrip()


def _resolve_device(device: str | torch.device | None) -> torch.device:
    if device is not None:
        return torch.device(device)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _load_state_dict(
    weights_path: Path, device: torch.device
) -> dict[str, torch.Tensor]:
    """Load a checkpoint safely.

    Uses safetensors for ``.safetensors`` files, and ``torch.load`` with
    ``weights_only=True`` otherwise so a malicious pickle cannot execute code on
    load. Tolerates both raw state dicts and training checkpoints that wrap the
    weights under a ``"model"`` key.
    """
    if weights_path.suffix == ".safetensors":
        try:
            from safetensors.torch import load_file
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "loading a .safetensors bundle requires the 'safetensors' package; "
                "install it with: pip install safetensors"
            ) from exc
        return load_file(str(weights_path), device=str(device))

    try:
        checkpoint = torch.load(weights_path, map_location=device, weights_only=True)
    except TypeError:  # very old torch without weights_only
        checkpoint = torch.load(weights_path, map_location=device)
    except Exception as exc:  # unpickling blocked a non-tensor global
        raise RuntimeError(
            f"could not load {weights_path.name} safely (weights_only=True). "
            "Re-save the checkpoint as a plain state dict or convert it to "
            ".safetensors."
        ) from exc
    if isinstance(checkpoint, dict) and "model" in checkpoint:
        return checkpoint["model"]
    return checkpoint
