"""Multi-accent seq2seq linguistic frontend for text-to-speech.

Maps normalised whole-sentence text to an accent-specific phonetic/linguistic
representation, using the sequence-to-sequence model of Sun & Richmond.

Public API:
    >>> from multi_accent_frontend import Frontend
    >>> fe = Frontend.from_pretrained("some-org/multi-accent-frontend")
    >>> fe.transcribe("HELLO WORLD", accent="gam")
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("multi-accent-frontend")
except PackageNotFoundError:  # not installed (e.g. run from source tree)
    __version__ = "0.0.0+unknown"

from .config import FrontendConfig, Vocab
from .frontend import Frontend
from .hub import BundlePaths, resolve_bundle

__all__ = [
    "BundlePaths",
    "Frontend",
    "FrontendConfig",
    "Vocab",
    "__version__",
    "resolve_bundle",
]
