"""Vendored research model code for the multi-accent seq2seq frontend.

These modules are the original research implementation (Sun & Richmond),
copied verbatim except that cross-module imports were made package-relative
so the code works once installed. They are considered internal: import the
public API from :mod:`multi_accent_frontend` instead.
"""
