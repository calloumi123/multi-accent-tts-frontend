"""Resolve a pretrained model bundle from a local directory or the HF Hub.

A *bundle* is the set of files needed to run inference:

* ``config.json`` -- model hyper-parameters and accent inventory
* ``src.vocab``   -- input character vocabulary
* ``tgt.vocab``   -- output phone vocabulary
* a weights file  -- a PyTorch checkpoint (``*.pth.tar`` / ``*.pth`` / ``*.bin``)

The trained weights are not distributed inside the source repository; they are
expected to live either in a local directory the user points at, or in a
Hugging Face Hub repo they name.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_FILE = "config.json"
DEFAULT_SRC_VOCAB_FILE = "src.vocab"
DEFAULT_TGT_VOCAB_FILE = "tgt.vocab"

# Recognised weight-file extensions, most preferred first (safetensors is the
# safe-by-construction default).
_WEIGHT_SUFFIXES: Sequence[str] = (".safetensors", ".pth.tar", ".pth", ".pt", ".bin", ".ckpt")


@dataclass(frozen=True)
class BundlePaths:
    """Resolved local filesystem paths for a pretrained bundle."""

    config: Path
    src_vocab: Path
    tgt_vocab: Path
    weights: Path


def _find_weights(directory: Path, explicit: str | None) -> Path:
    """Locate the weights file inside a resolved bundle directory."""
    if explicit is not None:
        candidate = directory / explicit
        if not candidate.is_file():
            raise FileNotFoundError(f"weights file not found: {candidate}")
        return candidate
    for suffix in _WEIGHT_SUFFIXES:
        matches = sorted(directory.glob(f"*{suffix}"))
        if not matches:
            continue
        if len(matches) == 1:
            return matches[0]
        # Ambiguous: prefer a conventional name, and warn about the guess.
        preferred = [m for m in matches if m.stem.startswith(("model", "best"))]
        chosen = (preferred or matches)[0]
        logger.warning(
            "multiple %s weight files in %s (%s); using %s. "
            "Pass weights_filename= to choose explicitly.",
            suffix, directory, ", ".join(m.name for m in matches), chosen.name,
        )
        return chosen
    raise FileNotFoundError(
        f"no weights file found in {directory}; expected one of "
        f"{', '.join(_WEIGHT_SUFFIXES)}. Pass weights_filename= to select one."
    )


def resolve_bundle(
    model: str | Path,
    *,
    config_filename: str = DEFAULT_CONFIG_FILE,
    src_vocab_filename: str = DEFAULT_SRC_VOCAB_FILE,
    tgt_vocab_filename: str = DEFAULT_TGT_VOCAB_FILE,
    weights_filename: str | None = None,
    revision: str | None = None,
    cache_dir: str | Path | None = None,
    token: str | None = None,
) -> BundlePaths:
    """Resolve ``model`` to concrete local file paths.

    Args:
        model: Either a local directory containing the bundle files, or a
            Hugging Face Hub repo id such as ``"someorg/multi-accent-frontend"``.
        config_filename: Name of the config file within the bundle.
        src_vocab_filename: Name of the source-vocab file within the bundle.
        tgt_vocab_filename: Name of the target-vocab file within the bundle.
        weights_filename: Explicit weights filename. If omitted, the first file
            matching a known checkpoint extension is used.
        revision: Optional Hub revision (branch, tag or commit) to download.
        cache_dir: Optional download cache directory for Hub downloads.
        token: Optional Hugging Face access token for private repos.

    Returns:
        A :class:`BundlePaths` with local paths to every required file.
    """
    path = Path(model)
    if path.is_dir():
        directory = path
    else:
        directory = _download_from_hub(
            repo_id=str(model),
            revision=revision,
            cache_dir=cache_dir,
            token=token,
        )

    config = directory / config_filename
    src_vocab = directory / src_vocab_filename
    tgt_vocab = directory / tgt_vocab_filename
    for required in (config, src_vocab, tgt_vocab):
        if not required.is_file():
            raise FileNotFoundError(
                f"missing required bundle file: {required}. A bundle needs "
                f"{config_filename}, {src_vocab_filename} and {tgt_vocab_filename}."
            )
    weights = _find_weights(directory, weights_filename)
    return BundlePaths(
        config=config,
        src_vocab=src_vocab,
        tgt_vocab=tgt_vocab,
        weights=weights,
    )


def _download_from_hub(
    repo_id: str,
    *,
    revision: str | None,
    cache_dir: str | Path | None,
    token: str | None,
) -> Path:
    """Download a bundle repo from the Hugging Face Hub and return its path."""
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:  # pragma: no cover - exercised only without extra
        raise ImportError(
            f"{repo_id!r} is not a local directory, so it is treated as a "
            "Hugging Face Hub repo id, which requires the 'huggingface_hub' "
            "package. Install it with: pip install huggingface_hub"
        ) from exc

    local_path = snapshot_download(
        repo_id=repo_id,
        revision=revision,
        cache_dir=str(cache_dir) if cache_dir is not None else None,
        token=token,
        allow_patterns=["*.json", "*.vocab", "*.safetensors", "*.pth", "*.pth.tar", "*.pt", "*.bin", "*.ckpt"],
    )
    return Path(local_path)
