"""Typed configuration and vocabulary handling for the frontend.

The research code stores model hyper-parameters in a JSON ``config.json`` and
two plain-text vocabulary files (``src.vocab`` for input characters and
``tgt.vocab`` for output phones). This module wraps those artifacts in typed
objects so the rest of the package doesn't have to juggle loosely-typed dicts.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ._research.generic_utils import load_config as _load_config_attrdict
from ._research.params import set_default_params

# Special tokens appended to every vocabulary, in this fixed order.
EOS_TOKEN = "EOS"
PAD_TOKEN = "PAD"
_NUM_SPECIAL_TOKENS = 2

# In the training data a space between words is represented by this character.
WORD_DELIMITER = "#"


@dataclass(frozen=True)
class Vocab:
    """A bidirectional token/index mapping with EOS and PAD appended.

    Attributes:
        token2idx: Mapping from token string to integer index.
        idx2token: Inverse mapping from integer index to token string.
    """

    token2idx: dict[str, int]
    idx2token: dict[int, str]

    @classmethod
    def from_file(cls, path: str | Path) -> Vocab:
        """Load a vocabulary from a ``<token>\\t<count>`` per-line file.

        ``EOS`` and ``PAD`` are appended automatically, matching the indexing
        used at training time.
        """
        path = Path(path)
        with path.open("r", encoding="utf-8") as handle:
            tokens = [
                line.split()[0]
                for line in handle
                if line.strip() != ""
            ]
        token2idx: dict[str, int] = {tok: idx for idx, tok in enumerate(tokens)}
        token2idx[EOS_TOKEN] = len(tokens)
        token2idx[PAD_TOKEN] = len(tokens) + 1
        idx2token: dict[int, str] = {idx: tok for tok, idx in token2idx.items()}
        return cls(token2idx=token2idx, idx2token=idx2token)

    @property
    def num_tokens(self) -> int:
        """Number of tokens *excluding* the EOS and PAD specials.

        This is the value the model expects for ``num_chars`` / ``num_phones``.
        """
        return len(self.token2idx) - _NUM_SPECIAL_TOKENS

    @property
    def eos_idx(self) -> int:
        return self.token2idx[EOS_TOKEN]

    @property
    def pad_idx(self) -> int:
        return self.token2idx[PAD_TOKEN]


@dataclass(frozen=True)
class FrontendConfig:
    """Model configuration plus the accent inventory.

    Wraps the research ``AttrDict`` config (accessible via :attr:`raw`) and
    derives the accent-name/index mapping the same way the research code does:
    accents are sorted alphabetically and numbered from zero.
    """

    raw: dict[str, object]
    accent2idx: dict[str, int]
    idx2accent: dict[int, str]

    @classmethod
    def from_file(cls, path: str | Path) -> FrontendConfig:
        """Load ``config.json`` and fill in default hyper-parameters."""
        config = _load_config_attrdict(str(path))
        config = set_default_params(config)
        data = config["data"]
        if not isinstance(data, dict) or not data:
            raise ValueError(
                f"config at {path!r} must contain a non-empty 'data' block "
                "listing the accents the model was trained on"
            )
        accent2idx = {name: idx for idx, name in enumerate(sorted(data.keys()))}
        idx2accent = {idx: name for name, idx in accent2idx.items()}
        return cls(raw=config, accent2idx=accent2idx, idx2accent=idx2accent)

    @property
    def accents(self) -> list[str]:
        """Accent names available in this model, in index order."""
        return [self.idx2accent[i] for i in range(len(self.idx2accent))]

    def resolve_accent(self, accent: str | int) -> int:
        """Turn an accent name or index into a validated integer index."""
        if isinstance(accent, bool):
            raise TypeError("accent must be a name or int index, not bool")
        if isinstance(accent, int):
            if accent not in self.idx2accent:
                raise ValueError(
                    f"accent index {accent} out of range; "
                    f"available accents: {self.accents}"
                )
            return accent
        if accent not in self.accent2idx:
            raise ValueError(
                f"unknown accent {accent!r}; available accents: {self.accents}"
            )
        return self.accent2idx[accent]
